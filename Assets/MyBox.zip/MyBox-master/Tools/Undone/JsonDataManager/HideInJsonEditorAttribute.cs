﻿//using System;
//
//namespace MyBox.Internal
//{
//	public class HideInJsonEditorAttribute : Attribute
//	{
//	}
//}